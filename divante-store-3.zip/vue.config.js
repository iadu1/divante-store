module.exports = {
  publicPath: ""
};
